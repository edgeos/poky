#!/bin/bash

if [ "tpm12" == $1 ]
   then
      DEV=vtpm12
      LEGACYTPM="yes"
   else
      DEV=vtpm20
      LEGACYTPM="no"
fi

# Clean up any that may have been previously created
if [ -e /tmp/${DEV} ]; then
   rm -r /tmp/${DEV}
fi
if [ -e /dev/${DEV} ]; then
   rm /dev/${DEV}
fi

mkdir -p /tmp/${DEV}
chmod 777 -R /tmp/${DEV}
chown tss:root -R  /tmp/${DEV}
echo "# Program invoked for creating certificates" > /etc/swtpm_setup.conf
echo "create_certs_tool= /usr/share/swtpm/swtpm-localca" >> /etc/swtpm_setup.conf
echo "create_certs_tool_config = /etc/swtpm-localca.conf" >> /etc/swtpm_setup.conf
echo "create_certs_tool_options = /etc/swtpm-localca.options" >> /etc/swtpm_setup.conf
if [ "no" = "${LEGACYTPM}" ]; then
  # TPM 2.0
  swtpm_setup --tpm2 --tpm-state /tmp/${DEV}/ --createek
  TPM_PATH=/tmp/${DEV} swtpm_cuse --tpm2 -n ${DEV}
else
  # TPM 1.2
  swtpm_setup --tpm-state /tmp/${DEV}/ --createek
  TPM_PATH=/tmp/${DEV} swtpm_cuse -n ${DEV}
fi

#Try to set file permissions on vtpm1 for 10 seconds
COUNT=10
while [ $COUNT -gt 0 ]; do
  COUNT=$((COUNT-1))
  if [ -a /dev/${DEV} ]; then
    chmod 777 /dev/${DEV}
    echo "Successfully set permissions on /dev/${DEV}"
    COUNT=0
  else
    sleep 1
  fi
done
